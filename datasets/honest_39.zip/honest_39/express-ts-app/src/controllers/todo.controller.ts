import { Request, Response } from 'express';
import * as TodoService from '../services/todo.service';

export const getAllTodos = (req: Request, res: Response) => {
  const todos = TodoService.getTodos();
  res.json(todos);
};

export const getTodo = (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const todo = TodoService.getTodoById(id);
  if (todo) {
    res.json(todo);
  } else {
    res.status(404).send('Todo not found');
  }
};

export const createTodo = (req: Request, res: Response) => {
  // TODO: Implement input validation
  const todo = req.body;
  const newTodo = TodoService.createTodo(todo);
  res.status(201).json(newTodo);
};

export const updateTodo = (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const todoUpdate = req.body;
  const updatedTodo = TodoService.updateTodo(id, todoUpdate);
  if (updatedTodo) {
    res.json(updatedTodo);
  } else {
    res.status(404).send('Todo not found');
  }
};

export const deleteTodo = (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const deleted = TodoService.deleteTodo(id);
  if (deleted) {
    res.status(204).send();
  } else {
    res.status(404).send('Todo not found');
  }
};