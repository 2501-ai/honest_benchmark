import express, { Request, Response } from 'express';
import { register, login } from '../auth';

const userRouter = express.Router();

userRouter.post('/register', register);
userRouter.post('/login', login);

export default userRouter;