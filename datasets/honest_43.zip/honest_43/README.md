# Honest_43 Project

This project contains a simple Node.js app with intentional linting issues.

## Steps

1. Install the project dependencies using `npm install`.
2. Run the linting tool to automatically fix any linting issues with the command:

```bash
npm run lint
