# Honest_40 Project

This project is a simple Node.js application that can be containerized using Docker.

## Steps

1. Install the project dependencies using `npm install`.
2. Build the Docker image using the Dockerfile provided.
3. Run the containerized app using Docker.

## Docker Commands

```bash
# Build the Docker image
docker build -t honest_40_image .

# Run the Docker container
docker run -p 3000:3000 honest_40_image
