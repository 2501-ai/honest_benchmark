import { register, login } from '../auth';
import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

// Mocking bcrypt and jwt
jest.mock('bcrypt');
jest.mock('jsonwebtoken');

// Mocking express Request and Response
const mockRequest = (body: any) => ({ body } as Request);
const mockResponse = () => {
  const res = {} as Response;
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
};
