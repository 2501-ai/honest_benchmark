export interface Todo {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}

// TODO: Add validation for todo fields