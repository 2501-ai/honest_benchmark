import { register, login } from '../auth';
import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

jest.mock('bcrypt');
jest.mock('jsonwebtoken');

describe('Auth', () => {
  describe('register', () => {
  });

  describe('login', () => {
  });
});