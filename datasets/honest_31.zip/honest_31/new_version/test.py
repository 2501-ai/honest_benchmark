import signal
import sys


def signal_handler(sig, frame):
    print('You pressed CTRL+C! Exiting...')
    # Perform any necessary cleanup here
    sys.exit(0)


# Register the signal handler for SIGINT (CTRL+C)
signal.signal(signal.SIGINT, signal_handler)


def main():
    pass


if __name__ == "__main__":
    main()
