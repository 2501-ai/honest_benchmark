import express, { Request, Response } from 'express';
import userRouter from './routes/user_router';

const app = express();
app.use(express.json());
app.use('/users', userRouter);

app.get('/', (req: Request, res: Response) => {
  res.send('Hello World!');
});

export default app;