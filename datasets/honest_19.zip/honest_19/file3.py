# functional.py

from typing import Callable, List, TypeVar, Any

T = TypeVar('T')
U = TypeVar('U')


# Utility functions
def identity(x: T) -> T:
    return x


def compose(*functions: Callable[..., Any]) -> Callable[..., Any]:
    def composed_function(arg: Any) -> Any:
        for func in reversed(functions):
            arg = func(arg)
        return arg

    return composed_function


def pipe(value: T, *functions: Callable[[T], U]) -> U:
    for func in functions:
        value = func(value)
    return value


# Higher-order functions
def map_function(func: Callable[[T], U], iterable: List[T]) -> List[U]:
    return [func(x) for x in iterable]


def filter_function(predicate: Callable[[T], bool], iterable: List[T]) -> List[T]:
    return [x for x in iterable if predicate(x)]


def reduce_function(func: Callable[[T, T], T], iterable: List[T], initial: T) -> T:
    result = initial
    for item in iterable:
        result = func(result, item)
    return result


# Example functions for testing
def double(x: int) -> int:
    return x * 2


def is_even(x: int) -> bool:
    return x % 2 == 0


def add(x: int, y: int) -> int:
    return x + y


# Example usage
if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]

    # Map example
    doubled_numbers = map_function(double, numbers)
    print("Doubled:", doubled_numbers)

    # Filter example
    even_numbers = filter_function(is_even, numbers)
    print("Even numbers:", even_numbers)

    # Reduce example
    sum_of_numbers = reduce_function(add, numbers, 0)
    print("Sum of numbers:", sum_of_numbers)

    # Compose example
    composed_function = compose(lambda x: x + 1, double)
    print("Composed function result:", composed_function(3))

    # Pipe example
    piped_result = pipe(3, double, lambda x: x + 1)
    print("Piped result:", piped_result)
