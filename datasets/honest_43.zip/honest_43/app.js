const express = require('express');
const app = express();

// This variable is unused and will trigger a linting issue
const unusedVar = 42;

app.get('/', (req, res) => {
    res.send('Hello, world!');
});

const port = 3000;
            app.listen(port, () => {
    console.log(`App running on port ${port}`);
});
