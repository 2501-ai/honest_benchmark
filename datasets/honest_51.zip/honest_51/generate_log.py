import random

total_lines = 500000

log_file_path = 'docker_log.txt'

log_messages = [
    "INFO: Starting container.",
    "INFO: Container running.",
    "INFO: Checking container health.",
    "WARN: High memory usage.",
    "INFO: Reloading configuration.",
    "INFO: Stopping container.",
    "INFO: Container restarted successfully.",
    "INFO: Updating Docker images.",
    "INFO: Cleaning up unused containers.",
    "DEBUG: Environment variable loaded."
]

def generate_log_line():
    timestamp = random.randint(1609459200, 1638316800)
    level = random.choice(["INFO", "WARN", "DEBUG"])
    message = random.choice(log_messages)
    return f"{timestamp} {level} {message}\n"

with open(log_file_path, 'w') as file:
    error_position = random.randint(0, total_lines)
    for i in range(total_lines):
        if i == error_position:
            error_line = "ERROR: Failed to bind socket on address 0.0.0.0:80: address already in use.\n"
            file.write(error_line)
        else:
            file.write(generate_log_line())
