import logging
import os
from sys import argv
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Function to download an image from a URL
def download_image(image_url, save_path):
    response = requests.get(image_url)
    if response.status_code == 200:
        with open(save_path, 'wb') as file:
            file.write(response.content)
    else:
        logger.error(f"Failed to download image. Status code: {response.status_code}")


# Function to search for Mario Kart images on Google Images
def search_and_download_image(name):
    search_url = f"https://www.google.com/search?tbm=isch&q={name}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }

    response = requests.get(search_url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find the first image in the search results
    img_tag = soup.find("img")
    if img_tag and 'src' in img_tag.attrs:
        img_url = img_tag['src']
        if not bool(urlparse(img_url).netloc):
            if img_url.startswith('/'):
                img_url = urljoin('https://www.google.com', img_url)
            else:
                img_url = urljoin('https://www.google.com', '/' + img_url)
        if img_url.startswith('https:/') and not img_url.startswith('https://'):
            img_url = img_url.replace('https:/', 'https://')
        logger.info(f"Image URL: {img_url}")
        save_path = os.path.join(os.getcwd(), "mariokart_image.jpg")
        download_image(img_url, save_path)
        logger.info(f"Image downloaded and saved to {save_path}")
    else:
        logger.info("No image found.")


if __name__ == "__main__":
    filename = argv[1]
    search_and_download_image(filename)
