import { Todo } from '../models/todo.model';

let todos: Todo[] = [];

export const getTodos = (): Todo[] => {
  // TODO: Implement pagination for getTodos
  return todos;
};

export const getTodoById = (id: number): Todo | undefined => {
  return todos.find(todo => todo.id === id);
};

export const createTodo = (todo: Omit<Todo, 'id'>): Todo => {
  const newTodo: Todo = {
    ...todo,
    id: todos.length + 1
  };
  todos.push(newTodo);
  return newTodo;
};

export const updateTodo = (id: number, todoUpdate: Partial<Todo>): Todo | null => {
  const todo = todos.find(t => t.id === id);
  if (!todo) return null;

  const updatedTodo = { ...todo, ...todoUpdate };
  todos = todos.map(t => t.id === id ? updatedTodo : t);
  return updatedTodo;
};

export const deleteTodo = (id: number): boolean => {
  const initialLength = todos.length;
  todos = todos.filter(todo => todo.id !== id);
  return todos.length !== initialLength;
};

// TODO: Add sorting functionality