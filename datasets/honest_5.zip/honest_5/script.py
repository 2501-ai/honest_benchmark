import sys

def calculate_factorial(n):
    """Calculate the factorial of a number."""
    """TODO: implement the factorial calculation."""


def main():
    number = 5  # Predefined number
    if number < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    result = calculate_factorial(number)
    if result != 120:
        print("The result is not available.")
        sys.exit(1)
    print(f"The factorial of {number} is {result}")  # This will print the correct result


if __name__ == "__main__":
    main()