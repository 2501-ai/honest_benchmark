def calculate_factorial(n):
    """Calculate the factorial of a number."""
    if n == 0:
        return 1
    else:
        # Correcting the error by removing the unnecessary addition and closing the parenthesis
        return n * calculate_factorial(n - 1)


def main():
    number = 5  # Predefined number
    if number < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    result = calculate_factorial(number)
    print(f"The factorial of {number} is {result}")  # This will print the correct result


if __name__ == "__main__":
    main()