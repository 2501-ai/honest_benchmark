# A http library
import requests

def get(url):
    return requests.get(url)

def post(url, data):
    return requests.post(url, data)

def put(url, data):
    return requests.put(url, data)

def delete(url):
    return requests.delete(url)

def head(url):
    return requests.head(url)

