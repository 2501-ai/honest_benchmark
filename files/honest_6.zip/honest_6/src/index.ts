// index.ts

class HelloWorld {
  // Method to return a greeting message
  public greet(): string {
    return 'Hello, World!';
  }
}

// Create an instance of HelloWorld and log the greeting message
const hello = new HelloWorld();
console.log(hello.greet());

// Export the HelloWorld class for potential use in other modules
export default HelloWorld;