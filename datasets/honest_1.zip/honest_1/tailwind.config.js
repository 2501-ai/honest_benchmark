/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html",
  ],
  theme: {
    extend: {
      colors: {
        // Add custom colors here if needed
      },
      fontFamily: {
        // Add custom fonts here if needed
      },
      spacing: {
        // Add custom spacing values here if needed
      },
    },
  },
  plugins: [
    // Add any Tailwind CSS plugins here
  ],
  variants: {
    extend: {
      // Add custom variants here if needed
    },
  },
  corePlugins: {
    // Disable or enable core plugins here if needed
  },
  purge: {
    enabled: process.env.NODE_ENV === 'production',
    content: [
      './src/**/*.{js,jsx,ts,tsx}',
      './public/index.html',
    ],
  },
}